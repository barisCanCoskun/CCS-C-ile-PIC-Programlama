#include <inttypes.h>
#include <avr/io.h>
#include <avr/pgmspace.h>

#include "ks0108.h"
#include "font12x16.h"
#include "font6x8.h"

const char pgmString[] PROGMEM = "http://www.apeTech.de\n\naffe.t@gmx.de";

int main(void) {
	volatile uint16_t i;
	struct font largeFont, smallFont;
	
	for(i=0; i<15000; i++);
	
	
	largeFont.width = FONT12X16_WIDTH;
	largeFont.height = FONT12X16_HEIGHT;
	largeFont.charData = Font12x16;
	
	smallFont.width = FONT6X8_WIDTH;
	smallFont.height = FONT6X8_HEIGHT;
	smallFont.charData = Font6x8;
	
	ks0108Init();
	ks0108GotoXY(0,4);
	ks0108PutString("Hallo Welt!", largeFont);
	ks0108GotoXY(0,28);
	ks0108PutStringP(pgmString, smallFont);

	while(1);
}
